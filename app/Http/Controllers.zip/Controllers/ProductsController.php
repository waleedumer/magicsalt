<?php

namespace App\Http\Controllers;

use App\Models\Products;
use App\Models\ProductCategories;
use App\Models\Brands;
use Illuminate\Http\Request;

class ProductsController extends Controller
{
    
    public function index()
    {
        $products = Products::with(['category', 'brand'])->get();
        return view('products.index', ['products' => $products]);
    }

    
    public function create()
    {
        $categories = ProductCategories::get();
        $brands = Brands::get();
        return view('products.create', ['categories' => $categories, 'brands' => $brands]);
    }

    
    public function store(Request $request)
    {
        $product = [
            'name' => $request->name,
        'purchase_price' => $request->purchase_price,
        'sale_price' => $request->sale_price,
        'purchase_vat' => $request->purchase_vat,
        'sale_vat' => $request->sale_vat,
        'brand_id' => $request->brand,
        'category_id' => $request->category,
        'image_url' => '0',
        'description' => $request->description,
        'product_code' => $request->productCode
        ];
        Products::create($product);
        return redirect()->route('products.index')->withStatus(__('Product Added Successfuly'));
    }

    
    public function show(Products $products)
    {
        //
    }

    
    public function edit(Products $products)
    {
        //
    }

    public function update(Request $request, Products $products)
    {
        //
    }

   
    public function destroy(Products $products)
    {
        //
    }
}
